import {square} from './square.js'
document.body.textContent = 'square(2) = ' + square(2);
