import {Foo} from './deps/foo';

console.log(Foo);
