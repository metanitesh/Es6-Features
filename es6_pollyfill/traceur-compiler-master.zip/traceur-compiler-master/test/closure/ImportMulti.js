import {Foo, Bar} from './deps/foo';

console.log(Foo);
