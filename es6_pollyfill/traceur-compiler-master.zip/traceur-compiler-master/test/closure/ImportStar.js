import * as foo from './deps/foo.js';

console.log(foo.Foo);
