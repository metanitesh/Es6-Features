export default 'default from foo.js';
