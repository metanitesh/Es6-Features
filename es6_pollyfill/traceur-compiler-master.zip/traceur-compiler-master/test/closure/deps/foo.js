export var Foo = 'Foo from foo.js';
