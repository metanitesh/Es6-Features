export var someExport = 'val';
