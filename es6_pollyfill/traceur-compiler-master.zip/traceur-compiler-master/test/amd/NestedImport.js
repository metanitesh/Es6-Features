import {Bar} from './deps/bar.js';

assert.equal('Bar from bar.js', Bar);
