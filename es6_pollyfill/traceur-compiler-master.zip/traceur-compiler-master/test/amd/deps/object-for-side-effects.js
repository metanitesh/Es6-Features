const object = {};
export {object as default};
