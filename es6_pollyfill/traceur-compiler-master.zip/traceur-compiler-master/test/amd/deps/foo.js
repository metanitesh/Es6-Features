export var Foo = 'Foo from foo.js';
export var Bar = 'Bar from foo.js';
export var Baz = 'Baz from foo.js';
