import object from './object-for-side-effects.js';
object.sideEffect++;
