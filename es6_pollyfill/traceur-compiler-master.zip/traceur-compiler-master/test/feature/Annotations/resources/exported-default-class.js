import {Anno} from './setup.js';

@Anno
export default class {
  @Anno
  annotatedMethod() {}
};
