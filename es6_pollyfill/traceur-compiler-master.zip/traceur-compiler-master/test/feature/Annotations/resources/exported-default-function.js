import {Anno} from './setup.js';

@Anno
export default function (@Anno x) {};
