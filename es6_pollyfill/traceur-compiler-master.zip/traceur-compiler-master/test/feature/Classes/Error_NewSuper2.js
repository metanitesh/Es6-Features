// Error: :6:3: Unexpected token }

class C {
  m() {
    new super
  }
}
