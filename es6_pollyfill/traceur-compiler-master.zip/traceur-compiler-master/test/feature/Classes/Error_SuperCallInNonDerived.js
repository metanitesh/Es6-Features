// Error: :5:5: super call is only allowed in derived constructor

class C {
  constructor() {
    super();
  }
}
