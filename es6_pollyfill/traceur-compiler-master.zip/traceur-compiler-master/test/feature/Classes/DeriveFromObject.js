class DerivedFromObject extends Object {
}

// ----------------------------------------------------------------------------

// TODO(rnystrom): No tests for this?
