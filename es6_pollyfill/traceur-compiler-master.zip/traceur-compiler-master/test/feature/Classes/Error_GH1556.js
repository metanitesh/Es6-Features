// Error: :5:19: Unexpected token =

// extends LeftHandSideExpression
// see https://github.com/google/traceur-compiler/issues/1556
class A extends B = C {}
