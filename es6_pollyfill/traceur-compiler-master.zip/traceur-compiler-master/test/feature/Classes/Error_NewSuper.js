// Error: :5:14: Unexpected token (

class C {
  m() {
    new super();
  }
}
