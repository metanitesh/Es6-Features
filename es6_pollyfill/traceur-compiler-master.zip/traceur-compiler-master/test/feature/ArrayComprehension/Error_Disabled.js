// Options: --array-comprehension=false
// Error: :4:14: Unexpected reserved word for

var array = [for (x of [0, 1, 2, 3, 4]) x];
