// Error: :5:17: Unexpected token ,
// Error: :5:12: Unexpected token ...

{
  let f = (...xs, x) => xs;
}