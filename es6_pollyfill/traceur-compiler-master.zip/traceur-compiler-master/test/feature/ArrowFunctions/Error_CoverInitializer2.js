// Error: :3:5: Unexpected token =

({a = 0});
