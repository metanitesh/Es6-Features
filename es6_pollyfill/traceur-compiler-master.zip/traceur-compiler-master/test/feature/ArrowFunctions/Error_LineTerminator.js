// Error: :4:1: Unexpected token =>

x
=>1
