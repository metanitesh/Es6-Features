export class q {
  foo() {
    throw 'g';
    console.log('class method');
  }
}

export default 4;

// export const ii = 'sdf';

var p = 5;

import * as Q from './test-file.js';
