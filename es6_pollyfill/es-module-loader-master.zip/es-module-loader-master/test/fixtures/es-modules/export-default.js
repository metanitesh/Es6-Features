export default function() {
  return 'test';
}
