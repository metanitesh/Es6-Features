System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      throw 'dep error';
    }
  };
});