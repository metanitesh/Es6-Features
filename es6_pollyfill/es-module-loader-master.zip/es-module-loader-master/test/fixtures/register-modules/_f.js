System.register(['./_g.js'], function (_export, _context) {
  "use strict";

  var f;
  return {
    setters: [function (_gJs) {
      var _exportObj = {};
      _exportObj.g = _gJs.g;

      _export(_exportObj);
    }],
    execute: function () {
      _export('f', f = 'f');

      _export('f', f);
    }
  };
});