System.register([], function (_export, _context) {
  "use strict";

  var p;
  return {
    setters: [],
    execute: function () {
      _export('p', p = 'p');

      _export('p', p);
    }
  };
});