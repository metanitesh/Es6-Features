System.register(['./export.js'], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_exportJs) {
      var _exportObj = {};
      _exportObj.q = _exportJs.t;
      _exportObj.z = _exportJs.p;

      _export(_exportObj);
    }],
    execute: function () {
      _export('default', 4);
    }
  };
});
