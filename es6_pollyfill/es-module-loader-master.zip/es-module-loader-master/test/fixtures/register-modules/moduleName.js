System.register([], function (_export, _context) {
  "use strict";

  var name;
  return {
    setters: [],
    execute: function () {
      _export("name", name = _context.id);

      _export("name", name);
    }
  };
});