System.register(['./es6-dep.js'], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_es6DepJs) {
      var _exportObj = {};
      _exportObj.p = _es6DepJs.p;

      _export(_exportObj);
    }],
    execute: function () {}
  };
});