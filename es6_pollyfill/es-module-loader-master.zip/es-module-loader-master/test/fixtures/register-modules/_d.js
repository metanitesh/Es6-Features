System.register([], function (_export, _context) {
  "use strict";

  var d;
  return {
    setters: [],
    execute: function () {
      _export('d', d = 'd');

      _export('d', d);
    }
  };
});