System.register([], function (_export, _context) {
  "use strict";

  var g;
  return {
    setters: [],
    execute: function () {
      _export('g', g = 'g');

      _export('g', g);
    }
  };
});